#!/usr/bin/env python3

# Import module nmap
import nmap3
# Import du module Flask
from flask import Flask

# Import du module sys pour redirect stdout
import sys, os

# On cree un objet de type Flask
app = Flask(__name__)


# On appelle la methode route sur le chemin d'acces /scan/une_ip_qui_est_fournie_par_le_client
@app.route("/scan/do/<string:host>")
# Ici on definie une fonction scan_port qui prend en parametre le parametre donne en URL
def scan_port(host):
    # Ici on retourne la valeur de "host".
    # Ici on va realiser un scanner de port soit en python, soit avec nmap sur l'adresse "host".
    # on fait le nmap ou le scan avec scapy
    nmap = nmap3.Nmap()
    results = nmap.scan_top_ports(host)
    with open(host+".scan.file", "w") as f:
        f.write(str(results))
    f.close()
    return ("scan for "+host+" done !")


@app.route("/scan/get/<string:host>")
def get_scan(host):
    # Ici on recupere le resultat de notre scan realise et stocke dans un fichier ou un BDD et on le "retourne"
    with open(host+".scan.file") as f:
        res=f.read()
    f.close()
    return (res)

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=6969)
